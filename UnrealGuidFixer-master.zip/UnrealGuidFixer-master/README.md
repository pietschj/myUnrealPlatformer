# GUID Fixer
UE5 Plugin (5.0) for resolving conflicting material GUIDs that cause errors in Swarm build and conflicting texture GUIDs that cause errors in texture streaming builds.

After placing in Project>Plugins, restart the Editor and you should have three new buttons under "Tools" in the toolbar in a section called "GUID Fixer"
Load the problematic level, click the button corresponding to your issue, and then Save All.

Much love and thanks to the original SwarmGuidFixer plugin by laggyluk, as well as the forums post it originated from.
https://github.com/laggyluk/SwarmGuidFixer

